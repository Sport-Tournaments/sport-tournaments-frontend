# Changelog

## 2025-07-29

- Add Sanity real-time content
- Update to React 19 and Next.js 15.4

## 2025-05-22

- Fix bug with focus styles

## 2025-04-28

- Update template to Tailwind CSS v4.1.4

## 2025-04-10

- Update template to Tailwind CSS v4.1.3

## 2025-03-22

- Update template to Tailwind CSS v4.0.15

## 2025-02-10

- Update template to Tailwind CSS v4.0.6

## 2025-01-23

- Update template to Tailwind CSS v4.0

## 2024-10-07

- Tidy tier data on pricing page

## 2024-09-23

- Fix incorrect date format on blog post page ([#1632](https://github.com/tailwindlabs/tailwind-plus-issues/issues/1632))
- Update all images to use absolute paths ([#1631](https://github.com/tailwindlabs/tailwind-plus-issues/issues/1631))

## 2024-09-13

- Update dependencies

## 2024-09-12

- Initial release
